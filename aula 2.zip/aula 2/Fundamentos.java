package cursoJava;

public class Fundamentos {

	public static void main(String[] args) {
		String nome = "Leonardo";
		int idade = 25;
		char sexo = 'M';
		double temperatura = 26.7;
		boolean arcondicionado = false;
		System.out.println("Nome: " + nome);
		System.out.println("Idade: " + idade);
		System.out.println("Sexo: " + sexo);
		System.out.println("Temperatura: " + temperatura);
		System.out.println("Ar condicionado: " + arcondicionado);

	}

}